import Image from "next/image"
import Button from "./Button"
import {StyledModal} from '@/lib/styles'
import { useEffect } from "react"

function EmailAuth({closeModal}){

  return(
    <StyledModal.EmailAuth>
      <main>
        <div><Image src="/svg/icon_check.svg" width={50} height={50} alt="" /></div>
        <div>이메일 인증</div>
        <div>이메일을 전송하였습니다.<br/>이메일의 인증코드 6자리를 입력하세요.</div>
        <div><Button.Main onClick={closeModal}>닫기</Button.Main></div>
      </main>
    </StyledModal.EmailAuth>
  )
}
export default {
  EmailAuth
}