import { StyledLayout } from "@/lib/styles"
import Aside from "./Aside"
import Header from "./Header"

function UserMain ({children, ...rest}) {

  return (
    <StyledLayout.UserMain>
      <Aside.UserMain />
      <Header.UserMain />
      <main>{children}</main>
    </StyledLayout.UserMain>
  )
}

function UserAuth ({children, ...rest}) {

  return (
    <StyledLayout.UserAuth>
      <Header.UserAuth />
      <main>{children}</main>
    </StyledLayout.UserAuth>
  )
}

function UserError ({children, ...rest}) {

  return (
    <StyledLayout.UserError>
      <main>{children}</main>
    </StyledLayout.UserError>
  )
}

export default {
  UserMain,
  UserAuth,
  UserError
}