import { StyledInput } from "@/lib/styles"
import { validate } from "@/lib/utils"
import { useState } from "react"


function AuthCode({setAuthCode, count}){
  const [validState, setValidState] = useState(99)
  const [authCodes, setAuthCodes] = useState(() => Array.from({length: count}, () => ('')))

  // input.focus 되었을때, input.value 일괄 선택
  function onFocus(e){
    e.target.select()
  }
  // input.value의 마지막 문자를 input.value로 적용하고
  // 해당 문자가 유효하면 authCodes 할당 후 다음 input.focus
  // 해당 문자가 유효하지 않으면 authCodes에 '' 할당
  function onChange(e){
    const index = Number(e.target.name)
    const lastChar = e.target.value.slice(-1)
    e.target.value = lastChar

    if(validate.test("eEn", lastChar) === 1) {
      const nextInput = e.target.parentElement?.nextElementSibling?.children[0]
      if(nextInput?.nodeName === "INPUT") nextInput.focus()
      setValidState(99)

      return setAuthCodes(prev => {
        const temp = [...prev]
        temp[index] = lastChar
        return temp
      })
    }else{
      lastChar ? setValidState(4) : setValidState(99)
    }

    return setAuthCodes(prev => {
      const temp = [...prev]
      temp[index] = ''
      return temp
    })
  }

  // enter 눌렀을 때, input.value가 유효한지 확인하고,
  // 다음 input이 있으면, input.focus
  // 다음 input이 없으면, authCodes 체크 후 setAuthCode()
  function onKeyDown(e){
    const {key, target: {value}} = e
    if(key === "Enter") {
      const validState = validate.test("eEn", value)
      if(validState !== 1) return setValidState(4)

      const nextInput = e.target.parentElement?.nextElementSibling?.children[0]
      if(nextInput?.nodeName === "INPUT") return nextInput.focus()

      const authCode = authCodes.join('')
      if(!authCode) return setValidState(5)
      if(authCode.length !== count) return setValidState(6)
      const resultState = validate.test("eEn", authCode)
      if(resultState === 1) setAuthCode(authCode)
      setValidState(resultState)
    }
  }

  return (
    <StyledInput.AuthCodeLabel validState={validState} count={count}>
        <p>인증코드</p>
        <ul>
          {authCodes.map((_, i) => (
            <li key={`authCodes/${i}`}>
              <input type="text" placeholder={i+1} onFocus={onFocus} onChange={onChange} onKeyDown={onKeyDown} name={i}/>
            </li>
          ))}
        </ul>
        <span>{validate.msg.authCode[validState]}</span>
    </StyledInput.AuthCodeLabel>
  )
}

export default {
  AuthCode
}