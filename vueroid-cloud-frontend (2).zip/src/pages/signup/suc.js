import { StyledPage } from "@/lib/styles";
import Image from "next/image";
import Layout from "@/components/Layout";

export default function SignupPage(){
  
  return (
    <StyledPage.SignupSuccess>
      <div><Image src={'/svg/icon_check.svg'} width={80} height={80}/></div>
      <div>Congratulation!!</div>
      <div>
        <span>Kim Amuke 님은{`  `}</span>
        <strong>KimAmuke</strong>
        <span>{`  `}아이디로 가입되셨습니다.</span>
        <div>Google의 aaa@gmail.com 계정과 연동되어 있습니다.</div>
      </div>
    </StyledPage.SignupSuccess>
  )
}

SignupPage.getLayout = (page) => <Layout.UserAuth>{page}</Layout.UserAuth>