import Layout from "@/components/Layout"
import Link from "next/link"
import styled from "@emotion/styled"

const Dev = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
  & > section {
    & > a {
      font-size: 30px;
      color: blue;
    }
  }
`
export default function DevPage(){

  return (
    <Dev>
      <section>
        <Link href="/signup"><a>/signup</a></Link>
        <div>- Twitter 버튼을 누르면, SNS 연동 확인 알림 컴포넌트가 출력됩니다</div>
        <div>- 이메일 인증 버튼을 누르면, 이메일 인증코드 전송 알림 모달 컴포넌트가 출력됩니다</div>
      </section>
      
      <section>
        <Link href="/signup/suc"><a>/signup/suc</a></Link>

      </section>

      <section>
        <Link href="/signin"><a>/signin</a></Link>

      </section>
    </Dev>
  )
}

DevPage.getLayout = (page) => <Layout.UserError>{page}</Layout.UserError>