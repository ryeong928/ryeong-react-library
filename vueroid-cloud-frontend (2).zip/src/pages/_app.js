import '@/lib/styles/globals.css'
import Layout from '@/components/Layout'
import { Hydrate, QueryClient, QueryClientProvider } from '@tanstack/react-query'
import Constants from '@/lib/Constants'
import { useState } from 'react'

function MyApp({ Component, pageProps }) {
  const getLayout = Component.getLayout || (page => <Layout.UserMain>{page}</Layout.UserMain>)
  const [queryClient] = useState(() => new QueryClient(Constants.QueryClient.config))

  return (
    <QueryClientProvider client={queryClient}>
      <Hydrate state={pageProps.dehydratedState}>
        {getLayout(<Component {...pageProps} />)}
      </Hydrate>
    </QueryClientProvider>
  )
}

export default MyApp
