import Button from "@/components/Button";
import { StyledCommon, StyledPage } from "@/lib/styles";
import theme from "@/lib/styles/theme";
import Link from "next/link";
import Image from "next/image";

const Data = {
  withIcon: {
    live: {
      style: {padding: "8px 14px 8px 12px", gap: 3, bgc: theme.Colors.blue1},
      img: {src: "/svg/icon_live.svg", width: 22, height: 22, alt: "icon_live"},
      text: {value: "LIVE", fs: 14, fw: 600},
    },
    fileView: {
      style: {padding: "8px 14px 8px 13px", gap: 5.2, bgc: theme.Colors.black1},
      img: {src: "/svg/icon_fileview.svg", width: 22, height: 22, alt: "icon_fileview"},
      text: {value: "File View", fs: 14, fw: 600},
    },
    setting: {
      style: {padding: "8px 14px 8px 11.8px", gap: 2.3, bgc: theme.Colors.black1},
      img: {src: "/svg/icon_setting.svg", width: 22, height: 22, alt: "icon_setting"},
      text: {value: "Setting", fs: 14, fw: 600},
    },
  }
}
export default function HomePage() {
  return(
    <StyledPage.UserHome>
      <main>
        <h1>Google Map</h1>
        <Image src='/svg/map_pin_orange.svg' width={72} height={73} alt='map_pin_orange' />
        <Image src='/svg/map_place.svg' width={72} height={73} alt='map_place' />
      </main>
      <sub><Link href="live"><a><Button.WithIcon data={Data.withIcon.live}/></a></Link></sub>
      <sub><Link href="files"><a><Button.WithIcon data={Data.withIcon.fileView}/></a></Link></sub>
      <sub><Link href="setting"><a><Button.WithIcon data={Data.withIcon.setting}/></a></Link></sub>
      <StyledCommon.Dev><Link href='dev'><a>개발 현황 페이지</a></Link></StyledCommon.Dev>
    </StyledPage.UserHome>
  )
}
