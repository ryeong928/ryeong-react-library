import { StyledPage } from "@/lib/styles";

export default function LivePage(){

  return(
    <StyledPage.Files>
      <h1>Files Page</h1>
    </StyledPage.Files>
  )
}