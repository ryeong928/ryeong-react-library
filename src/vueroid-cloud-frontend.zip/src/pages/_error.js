import Layout from "@/components/Layout";
import { StyledPage } from "@/lib/styles";
import Link from "next/link";

export default function ErrorPage(){

  return(
    <StyledPage.UserError>
      <h1>Error Page!</h1>
      <Link href="/"><a>Go Home</a></Link>
    </StyledPage.UserError>
  )
}

ErrorPage.getLayout = (page) => (<Layout.UserError>{page}</Layout.UserError>)