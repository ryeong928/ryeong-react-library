import { StyledPage } from "@/lib/styles";

export default function LivePage(){

  return(
    <StyledPage.Live>
      <h1>Live Page</h1>
    </StyledPage.Live>
  )
}