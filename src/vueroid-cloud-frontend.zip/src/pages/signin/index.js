import { StyledPage } from "@/lib/styles";
import Layout from "@/components/Layout";
import Input from "@/components/Input";
import { useState } from "react";

const Data = {
  authCode: {
    count: 6
  }
}
export default function SigninPage(props){
  const [authCode, setAuthCode] = useState()
  console.log("authCode", authCode)
  return(
    <StyledPage.Signin>
      <h1>Signup Page</h1>
      <Input.AuthCode setAuthCode={setAuthCode} count={6}/>
      <Input.AuthCode setAuthCode={setAuthCode} count={6}/>
      <Input.AuthCode setAuthCode={setAuthCode} count={6}/>
    </StyledPage.Signin>
  )
}

SigninPage.getLayout = (page) => <Layout.UserAuth>{page}</Layout.UserAuth>