import { StyledPage } from "@/lib/styles";

export default function UserSettingPage(){

  return(
    <StyledPage.UserSetting>
      <h1>UserSetting Page</h1>
    </StyledPage.UserSetting>
  )
}