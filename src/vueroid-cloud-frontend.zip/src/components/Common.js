import Image from "next/image"
import {StyledCommon} from '@/lib/styles'
import {ConditionalWrapper} from '@/lib/utils'

function Loading({isLoading}){
  return isLoading ? <div>Loading...</div> : null
}
function Error({isError}){
  return isError ? <div>Error Occured</div> : null
}
function NotStarted(){
  return <div>...</div>
}

function Img({data: {wrapper, ...rest}}){
  return (
    <ConditionalWrapper 
      condition={wrapper ? true : false} 
      wrapper={children => <StyledCommon.ImageWrapper {...wrapper}>{children}</StyledCommon.ImageWrapper>}
    >
      <Image {...rest} />
    </ConditionalWrapper>
  )
}

// data: {value, fc: string, fw, fs: number}
function Text({data: {value, ...rest}}){
  return <StyledCommon.Text {...rest}>{value}</StyledCommon.Text>
}

export default {
  Loading,
  Error,
  NotStarted,
  Img,
  Text,
}