import Image from "next/image";
import { StyledButton } from "@/lib/styles";
import Common from "./Common";
import Constants from "@/lib/Constants";


function Main({children, ...rest}){
  return <StyledButton.Main {...rest}>{children}</StyledButton.Main>
}

// sns: string
function SNS({sns, setAccount}){
  function onClick(e){
    if(sns.toLowerCase() === "twitter") setAccount({sns, email: "ttt@twitter.com"})
    alert(sns)
  }

  return (
    <StyledButton.SNS onClick={onClick}>
      <div><Image src={`/svg/icon_${sns.toLowerCase()}.svg`} width={40} height={40} alt={sns} /></div>
      <span>{sns}</span>
    </StyledButton.SNS>
  )
}

// style: {padding, bgc: string, gap: number}
// img: {src, alt: string, width, height: number}
// text: {value, fc: string, fw, fs: number}
function WithIcon({data: {img, text, style, ...rest}}){
  return (
    <StyledButton.WithIcon {...rest} {...style}>
      <div><Common.Img data={img} /></div>
      <div><Common.Text data={text} /></div>
    </StyledButton.WithIcon>
  )
}

export default {
  Main,
  SNS,
  WithIcon
}