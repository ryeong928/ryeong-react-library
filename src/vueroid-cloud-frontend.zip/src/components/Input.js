import { StyledInput } from "@/lib/styles"
import { useRef, useState } from "react"


function AuthCode({setAuthCode, count}){
  console.log("count: ", count)
  const [state, setState] = useState(0)
  const codeRef = useRef(Array.from({length: count}, () => ('')))
  console.log('AuthCode: ', codeRef.current)

  function onChange(e){
    const index = Number(e.target.name)
    const lastChar = e.target.value.slice(-1)
    e.target.value = lastChar
    const authCode = codeRef.current
    if(authCode) authCode[index] = lastChar
    console.log("onChange ", index, lastChar)
  }
  function onKeyDown(e){
    if(e.keyCode !== 13) return
    const nextInput = e.target.parentElement?.nextElementSibling?.children[0]
    if(!nextInput || nextInput.nodeName !== "INPUT") return console.log("Authcode End")
    nextInput.focus()
  }
  return (
    <StyledInput.AuthCode valid={state} count={count}>
        <p>인증코드</p>
        <ul>
          {codeRef.current?.map((_, i) => (
            <li key={`authCode/${i}`}>
              <input type="text" placeholder={i+1} onChange={onChange} onKeyDown={onKeyDown} name={i}/>
            </li>
          ))}
        </ul>
        <span>{state === 2 && '에러: 코드오류입니다'}</span>
    </StyledInput.AuthCode>
  )
}

export default {
  AuthCode
}