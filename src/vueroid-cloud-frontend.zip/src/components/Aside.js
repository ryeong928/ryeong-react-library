import theme from "@/lib/styles/theme";
import Mock from "@/lib/Mock";
import { StyledAside } from "@/lib/styles";
import { useEffect, useState } from "react";
import Button from '@/components/Button'
import Image from "next/image";
import Device from "./Device";

const Data = {
  userMain: {
    withIcons: [
      {
        style: {padding: "10px 13px 10px 10px"},
        img: {src: "/svg/icon_main_off.svg", width: 30, height: 30, alt: "icon_main_off", wrapper: true},
        text: {value: "MAIN"},
      },
      {
        style: {padding: "10px 13px 10px 10px"},
        img: {src: "/svg/icon_car_off.svg", width: 30, height: 30, alt: "icon_main_off", wrapper: true},
        text: {value: "운행기록"}
      },
      {
        style: {padding: "10px 13px 10px 10px"},
        img: {src: "/svg/icon_setting_off.svg", width: 30, height: 30, alt: "icon_main_off", wrapper: true},
        text: {value: "설정"}
      },
    ],
    addVueroid: {
      style: {padding: "14px 17px 14px 13px", gap: 6, bgc: theme.Colors.blue1},
      img: {src: "/svg/icon_plus.svg", width: 14, height: 14, alt: "icon_plus"},
      text: {value: "VUEROID 추가", fw: 600}
    }
  }
}
function UserMain(){
  const [devices, setDevices] = useState()
  useEffect(() => {
    setDevices(Mock.Devices)
  }, [])

  function onClick0(e){
    window.alert('idx 0: ', e.target)
  }
  function onClick1(e){
    window.alert('idx 1: ', e.target)
  }
  function onClick2(e){
    window.alert('idx 2: ', e.target)
  }
  const onClicks = [onClick0, onClick1, onClick2]

  return (
    <StyledAside.MainAside>
      <section>
        <div><Image src="/svg/icon_home_off.svg" width={35} height={34} alt={"icon_home_off"} /></div>

        <div>
          <div>
            <span>이보미님 환영합니다.</span>
            <Image src="/svg/icon_arrow_dw.svg" width={12} height={12} alt={"icon_arrow_dw"} />
          </div>
        </div>

        <div>
          <div><Image src="/webp/icon_kor.webp" width={31} height={39} alt={"icon_kor"} /></div>
          <div><Image src="/svg/icon_alert.svg" width={32} height={32} alt={"icon_alert"} /><button>11</button></div>
          <div><Image src="/svg/icon_info.svg" width={32} height={32} alt={"icon_info"} /></div>
        </div>
      </section>

      <section>
        {Data.userMain.withIcons.map((v, i) => (<Button.WithIcon key={`aside/withicon/${i}`} data={{...v, onClick: onClicks[i]}}/>))}
      </section>

      <section>
        <div><Button.WithIcon data={Data.userMain.addVueroid} /></div>
        <ul>{devices?.map(d => (<Device.Item key={d.sn} data={d} selected={true}/>))}</ul>
      </section>
    </StyledAside.MainAside>
  )
}

export default {
  UserMain
}

/*
*/