import { useDevice } from "@/lib/store"
import { StyledDevice } from "@/lib/styles"
import Label from "./Label"

// data: device data
// selected: boolean
// online: boolean
function Item({data, selected, online}){
  const {selectedDeviceSn, setSelectedDeviceSn} = useDevice(state => state)

  function onClick(e){
    if(!selected) return
    const device = e.target.closest('li')
    const sn = device?.dataset.sn
    if(!device || !sn) return console.log("onDeviceClick: wrong device")
    setSelectedDeviceSn(sn)
  }

  return (
    <StyledDevice.Item className={data.sn === selectedDeviceSn ? "mainaside-selected-sn" : ""} data-sn={data.sn} onClick={onClick} selected={selected}>
      {selected && <p />}
      <div><Label.DrivingState state={data.state} /></div>
      <div>{data.model}<br />{data.name}</div>
      <div><span>SN</span><span>{data.sn}</span></div>
      {online && <sub>{data.online}</sub>}
    </StyledDevice.Item>
  )
}

export default {
  Item
}