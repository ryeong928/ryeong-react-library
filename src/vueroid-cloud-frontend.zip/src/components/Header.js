import { StyledHeader } from "@/lib/styles";
import Link from "next/link";
import Image from "next/image";
import Button from "./Button";
import theme from "@/lib/styles/theme";
import Device from "./Device";
import { useDevice } from "@/lib/store";
import Mock from "@/lib/Mock";

const Header = {
  userAuth: {
    href: ['/', '/signup', '/signin', '/notice'],
    withIcons: [
      {
        style: {padding: "10px 13px 10px 10px", bgc: theme.Colors.blue1},
        img: {src: '/svg/icon_join.svg', width: 30, height: 30, alt: 'icon_join'},
        text: {value: '회원가입'}
      },
      {
        style: {padding: "10px 13px 10px 10px"},
        img: {src: '/svg/icon_login.svg', width: 30, height: 30, alt: 'icon_login'},
        text: {value: '로그인'}
      },
      {
        style: {padding: "10px 13px 10px 10px"},
        img: {src: '/svg/icon_notice.svg', width: 30, height: 30, alt: 'icon_notice'},
        text: {value: '공지사항'}
      },
    ]
  }
}


function UserMain(){
  const selectedDeviceSn = useDevice(state => state.selectedDeviceSn)
  const device = Mock.Devices.find(d => d.sn == selectedDeviceSn)
  
  return(
    !selectedDeviceSn ? null : 
    (<StyledHeader.UserMain>
      <div><div><Image src={'/webp/vueroid_img.webp'} width={130} height={130} alt={'vueroid_img'} /></div></div>

      <div><Device.Item data={device} selected={false} online={true}/></div>

      <div>
        <div>
          <p>최종위치</p>
          <span>123.1234567, -98.987654321</span>
          <div><Image src={'/svg/icon_mappin.svg'} width={25} height={25} alt={'icon_mappin'} /></div>
        </div>
        <div>
          <p>지오펜싱</p>
          <span>회사, 집</span>
        </div>
        <div>
          <p>지도</p>
          <span>경시 성남시 분당구 삼평동 판교역로 160</span>
        </div>
        <div>
          <p>그룹없음</p>
        </div>
      </div>
    </StyledHeader.UserMain>)
  )
}

function UserAuth(){
  return(
    <StyledHeader.UserAuth>
      <Link href="/"><a>
        <Image src='/svg/icon_home_off.svg' width={35} height={34} alt="icon_home_off"/>
      </a></Link>

      {Header.userAuth.withIcons.map((v, i) => (
          <Link href={Header.userAuth.href[i+1]} key={`header/userauth/${i}`}><a>
            <Button.WithIcon data={v} />
          </a></Link>)
      )}
    </StyledHeader.UserAuth>
  )
}

export default {
  UserMain,
  UserAuth
}