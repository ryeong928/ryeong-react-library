import {StyledLabel} from '@/lib/styles'
import Constants from '@/lib/Constants'

// state: string
function DrivingState({state}){
  const drivingState = Constants.DrivingState[state]
  return (
    <StyledLabel.DrivingState color={drivingState.state}>
      {drivingState.state !== 0 && <div />}
      <span>{drivingState?.text}</span>
    </StyledLabel.DrivingState>
  )
}

export default {
  DrivingState
}